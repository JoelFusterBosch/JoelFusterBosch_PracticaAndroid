# PMDM_UD01_AndroidRecursos

Recursos per a la unitat 1 del mòdul de PMDM:

* Projecte [Comptador](Comptador), basat en vistes XML
* Projecte [ComptadorMVVM](comptadorMVVM), basat en vistes XML, i fent ús d'un ViewModel per a la gestió de l'estat
* Projecte [ComptadorComposable](ComptadorComposable), amb el comptador basat en Jetpack COmpose
